Contenuto della cartella:
=========================

- makefile
- run.cpp
- README.md


Compilazione:
=============

Metodo 1
--------
Da terminale entrare nella cartella e digitare *make*

Metodo 2
--------
Da terminale entrare nella cartella e digitare
	g++ run.cpp -o run

Metodo 3
--------
Compilare in una qualche maniera run.cpp ;-)

Esecuzione:
===========
Da terminale digitare
	./run directoryCheContieneIFile
come output verra' generato un file output.txt


